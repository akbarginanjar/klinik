<header id="header" class="header sticky-top">

    <div class="topbar d-flex align-items-center">
        <div class="container d-flex justify-content-center justify-content-md-between">
            <div class="contact-info d-flex align-items-center">
                <a href="https://www.instagram.com/klinikpratamahegar?igsh=MTdsODgwZGdyd3RubA==" target="_blank"><i
                        class="bi bi-instagram d-flex align-items-center ms-4"><span>@klinikpratamahegar</span></i></a>
                <i class="bi bi-phone d-flex align-items-center ms-4"><span>082117105560</span></i>
            </div>
            <div class="social-links d-none d-md-flex align-items-center">
                
            </div>
        </div>
    </div><!-- End Top Bar -->

    <div class="branding d-flex align-items-center">

        <div class="container position-relative d-flex align-items-center justify-content-between">
            <a href="/" class="logo d-flex align-items-center me-auto">
                <!-- Uncomment the line below if you also wish to use an image logo -->
                <!-- <img src="assets/img/logo.png" alt=""> -->
                <h1 class="sitename"><img src="<?php echo e(asset('images/logo-klinik-hegar.png')); ?>" alt=""> Klinik Hegar
                </h1>
            </a>

            <nav id="navmenu" class="navmenu">
                <ul>
                    <li><a href="/" class="<?php echo e(Request::is('') ? 'active' : ''); ?>">Beranda<br></a></li>
                    <?php if(Request::is('dokter') && Request::is('galeri')): ?>
                        <li><a href="#about">Tentang
                                Kami</a></li>
                    <?php else: ?>
                        <li><a href="/#about">Tentang
                                Kami</a></li>
                    <?php endif; ?>
                    <?php if(Request::is('dokter') && Request::is('galeri')): ?>
                        <li><a href="#services">Layanan</a></li>
                    <?php else: ?>
                        <li><a href="/#services">Layanan</a></li>
                    <?php endif; ?>
                    <?php if(Request::is('dokter') && Request::is('galeri')): ?>
                        <li><a href="#departments">Kerja Sama</a></li>
                    <?php else: ?>
                        <li><a href="/#departments">Kerja Sama</a></li>
                    <?php endif; ?>
                    <li><a href="/dokter" class="<?php echo e(Request::is('dokter') ? 'active' : ''); ?>">Dokter</a></li>
                    <li><a href="/galeri" class="<?php echo e(Request::is('galeri') ? 'active' : ''); ?>">Galeri</a></li>
                    
                    <?php if(Request::is('dokter') && Request::is('galeri')): ?>
                        <li><a href="#contact">Kontak Kami</a></li>
                    <?php else: ?>
                        <li><a href="/#contact">Kontak Kami</a></li>
                    <?php endif; ?>
                </ul>
                <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
            </nav>

            

        </div>

    </div>

</header>
<?php /**PATH /Users/mac/Documents/datakerja/Floppy/klinik/resources/views/layouts/partials/navbar.blade.php ENDPATH**/ ?>