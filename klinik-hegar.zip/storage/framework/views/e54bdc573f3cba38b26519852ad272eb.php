<?php $__env->startSection('content'); ?>
    <!-- Doctors Section -->
    <section id="doctors" class="doctors section">

        <!-- Section Title -->
        <div class="container section-title" data-aos="fade-up">
            <h2>Dokter</h2>
            <p>Klinik Pratama Hegar</p>
        </div><!-- End Section Title -->

        <div class="container">

            <div class="row gy-4">

                <div class="col-lg-3">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/dr. Feny.jpg')); ?>"
                                style="height: 300px; width: 100%; object-fit: cover;" class="rounded" alt="">
                            <h4 class="text-center mt-3"><b>Dr. Fenny</b></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/dr. Ajat.jpg')); ?>"
                                style="height: 300px; width: 100%; object-fit: cover;" class="rounded" alt="">
                            <h4 class="text-center mt-3"><b>Dr. Ajat</b></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/dr. Ayu.jpg')); ?>"
                                style="height: 300px; width: 100%; object-fit: cover;" class="rounded" alt="">
                            <h4 class="text-center mt-3"><b>Dr. Ayu</b></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/dr. Fifi.jpg')); ?>"
                                style="height: 300px; width: 100%; object-fit: cover;" class="rounded" alt="">
                            <h4 class="text-center mt-3"><b>Dr. Fifi</b></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/dr. Rena.jpg')); ?>"
                                style="height: 300px; width: 100%; object-fit: cover;" class="rounded" alt="">
                            <h4 class="text-center mt-3"><b>Dr. Rena</b></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/dr. Maretta.jpg')); ?>"
                                style="height: 300px; width: 100%; object-fit: cover;" class="rounded" alt="">
                            <h4 class="text-center mt-3"><b>Dr. Maretta</b></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/dr. Nafsia.jpg')); ?>"
                                style="height: 300px; width: 100%; object-fit: cover;" class="rounded" alt="">
                            <h4 class="text-center mt-3"><b>Dr. Nafsia</b></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/dr. Rahmaniati.jpg')); ?>"
                                style="height: 300px; width: 100%; object-fit: cover;" class="rounded" alt="">
                            <h4 class="text-center mt-3"><b>Dr. Rahmaniati</b></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/dr. Yudi Garnadi.jpg')); ?>"
                                style="height: 300px; width: 100%; object-fit: cover;" class="rounded" alt="">
                            <h4 class="text-center mt-3"><b>Dr. Yudi Garnadi</b></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/dr. Yuniarni.jpg')); ?>"
                                style="height: 300px; width: 100%; object-fit: cover;" class="rounded" alt="">
                            <h4 class="text-center mt-3"><b>Dr. Yuniarni</b></h4>
                        </div>
                    </div>
                </div>

                

            </div>

        </div>

    </section><!-- /Doctors Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Documents/datakerja/Floppy/klinik/resources/views/dokter.blade.php ENDPATH**/ ?>